
export class Students{
        id:number;
        username: string;
        password: string;
        fullname: string;
        email: string;
        gender: string;
        birthday: Date;
}
