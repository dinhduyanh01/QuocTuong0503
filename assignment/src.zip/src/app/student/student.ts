export class Student{
    taikhoan : String
    matkhau : String
}