import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pro3',
  templateUrl: './pro3.component.html',
  styleUrls: ['./pro3.component.css']
})
export class Pro3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
