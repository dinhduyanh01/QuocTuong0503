import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-choi',
  templateUrl: './choi.component.html',
  styleUrls: ['./choi.component.css']
})
export class ChoiComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
